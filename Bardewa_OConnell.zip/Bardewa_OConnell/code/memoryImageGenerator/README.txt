README:

This is how you run the program in unix based machine, provided you have gcc and python3 installed

Type the following command. This will generate memoryImage and expected output files


python3 assemblyCodeGenerator.py >>inputfile.txt && python3 assembler.py >>memoryImage.txt && make && ./dataGenerator